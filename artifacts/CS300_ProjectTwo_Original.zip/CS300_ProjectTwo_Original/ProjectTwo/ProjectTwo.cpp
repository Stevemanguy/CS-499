//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Steven Gifford
// Version     : 1.0
// Copyright   : Copyright � 2025
// Description : ABCU Advising Assistance Program (BST)
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <unordered_set>
#include <cctype>

using namespace std;

/*  Data Structures  */

// Course record
struct Course {
    string number;            // e.g., CSCI200
    string title;             // e.g., Data Structures
    vector<string> prereqs;   // zero or more prerequisite course numbers
};

// BST node
struct Node {
    Course data;
    Node* left;
    Node* right;
    explicit Node(const Course& c) : data(c), left(nullptr), right(nullptr) {}
};

/*  Helpers  */

// Trim leading/trailing whitespace
static string trim(const string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

// Split by comma (plain CSV for this assignment)
static vector<string> splitCSV(const string& line) {
    vector<string> out;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) out.push_back(trim(token));
    return out;
}

// Uppercase utility for case-insensitive course keys
static string toUpperStr(string s) {
    for (char& ch : s) ch = static_cast<char>(toupper(static_cast<unsigned char>(ch)));
    return s;
}

/*  Binary Search Tree  */

class CourseBST {
public:
    CourseBST() : root(nullptr) {}
    ~CourseBST() { freeTree(root); }

    // Insert by course number. Replaces data if the key already exists.
    void insert(const Course& c) { root = insertRec(root, c); }

    // Find a course by number; returns nullptr when not found.
    const Course* find(const string& number) const {
        Node* cur = root;
        string key = toUpperStr(number);
        while (cur) {
            if (key == cur->data.number) return &cur->data;
            cur = (key < cur->data.number) ? cur->left : cur->right;
        }
        return nullptr;
    }

    // In-order traversal prints in alphanumeric order.
    void printInOrder() const { printRec(root); }

    // Reset the tree to empty (used when reloading).
    void clear() { freeTree(root); root = nullptr; }

private:
    Node* root;

    static Node* insertRec(Node* n, const Course& c) {
        if (!n) return new Node(c);
        if (c.number < n->data.number) n->left = insertRec(n->left, c);
        else if (c.number > n->data.number) n->right = insertRec(n->right, c);
        else n->data = c; // replace on duplicate key
        return n;
    }

    static void printRec(Node* n) {
        if (!n) return;
        printRec(n->left);
        cout << n->data.number << ", " << n->data.title << '\n';
        printRec(n->right);
    }

    static void freeTree(Node* n) {
        if (!n) return;
        freeTree(n->left);
        freeTree(n->right);
        delete n;
    }
};

/*  File Load + Validation  */

struct LoadResult {
    bool ok = false;
    string message;
    vector<Course> courses;
};

// Reads the file, builds course records, and validates that every prerequisite exists.
// Returns all errors up front so the user can fix the file before loading.
static LoadResult readAndValidate(const string& path) {
    LoadResult r;

    ifstream in(path);
    if (!in) { r.message = "Could not open file."; return r; }

    vector<Course> temp;
    unordered_set<string> seen;   // for prerequisite existence checks

    string line;
    while (getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;

        auto parts = splitCSV(line);
        if (parts.size() < 2) {
            r.message = "Invalid line (needs course number and title): " + line;
            return r;
        }

        Course c;
        c.number = toUpperStr(parts[0]);
        c.title = parts[1];
        for (size_t i = 2; i < parts.size(); ++i) {
            if (!parts[i].empty()) c.prereqs.push_back(toUpperStr(parts[i]));
        }

        temp.push_back(c);
        seen.insert(c.number);
    }

    // Check that every listed prerequisite appears as a course in the file.
    for (const auto& c : temp) {
        for (const auto& p : c.prereqs) {
            if (!seen.count(p)) {
                r.message = "Prerequisite " + p + " not found for course " + c.number + ".";
                return r;
            }
        }
    }

    r.ok = true;
    r.courses = std::move(temp);
    return r;
}

// Inserts loaded courses into the BST.
static void buildBST(const vector<Course>& courses, CourseBST& bst) {
    for (const auto& c : courses) bst.insert(c);
}

/*  UI Actions  */

// Prints a single course with its prerequisites.
static void printCourse(const CourseBST& bst, const string& queryRaw) {
    string query = trim(queryRaw);
    if (query.empty()) { cout << "Invalid course number.\n"; return; }

    const Course* c = bst.find(query);
    if (!c) { cout << toUpperStr(query) << " not found.\n"; return; }

    cout << c->number << ", " << c->title << '\n';
    cout << "Prerequisites: ";
    if (c->prereqs.empty()) {
        cout << "None\n";
    }
    else {
        for (size_t i = 0; i < c->prereqs.size(); ++i) {
            if (i) cout << ", ";
            cout << c->prereqs[i];
        }
        cout << '\n';
    }
}

/* Main */

int main() {
    cout << "Welcome to the course planner." << '\n';

    CourseBST bst;
    bool loaded = false;

    while (true) {
        cout << "1. Load Data Structure." << '\n';
        cout << "2. Print Course List." << '\n';
        cout << "3. Print Course." << '\n';
        cout << "9. Exit" << '\n';
        cout << "What would you like to do? ";

        string choiceStr;
        if (!getline(cin, choiceStr)) break;
        if (choiceStr.empty()) continue;

        int choice = -1;
        try { choice = stoi(choiceStr); }
        catch (...) { choice = -1; }

        if (choice == 1) {
            // Hardcode the filename so it loads automatically
            string path = "CS 300 ABCU_Advising_Program_Input.csv";

            auto res = readAndValidate(path);
            if (!res.ok) {
                cout << res.message << '\n';
                continue;
            }
            bst.clear();
            buildBST(res.courses, bst);
            loaded = true;

            cout << "Courses loaded successfully from " << path << '\n';
        }

        else if (choice == 2) {
            if (!loaded) {
                cout << "Please load the data structure first (option 1)." << '\n';
                continue;
            }
            cout << "Here is a sample schedule:" << '\n';
            bst.printInOrder();

        }
        else if (choice == 3) {
            if (!loaded) {
                cout << "Please load the data structure first (option 1)." << '\n';
                continue;
            }
            cout << "What course do you want to know about? ";
            string q;
            getline(cin, q);
            printCourse(bst, q);

        }
        else if (choice == 9) {
            cout << "Thank you for using the course planner!" << '\n';
            break;

        }
        else {
            cout << choiceStr << " is not a valid option." << '\n';
        }
    }
    return 0;
}
