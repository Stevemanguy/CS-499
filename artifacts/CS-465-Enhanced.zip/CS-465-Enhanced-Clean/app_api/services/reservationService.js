const mongoose = require('mongoose');

const Trip = mongoose.model('trips');
const Reservation = mongoose.model('reservations');

const cleanTripCode = function(tripCode) {
  return String(tripCode).trim().toUpperCase();
};

const getTripPrice = function(trip) {
  const price = Number(String(trip.perPerson).replace(/[^0-9.]/g, ''));
  return isNaN(price) ? 0 : price;
};

const createReservation = async function(customerEmail, tripCode, travelers) {
  if (!customerEmail || !tripCode || !travelers) {
    throw new Error('Missing reservation information');
  }

  const cleanCode = cleanTripCode(tripCode);
  const travelerCount = Number(travelers);

  if (travelerCount < 1 || travelerCount > 10) {
    throw new Error('Traveler count must be between 1 and 10');
  }

  const trip = await Trip.findOne({ code: cleanCode });

  if (!trip) {
    throw new Error('Trip not found');
  }

  if (trip.capacity === undefined) {
    trip.capacity = 20;
  }

  if (trip.remainingCapacity === undefined) {
    trip.remainingCapacity = trip.capacity;
  }

  if (trip.remainingCapacity < travelerCount) {
    throw new Error('Not enough space available');
  }

  const tripPrice = getTripPrice(trip);
  const totalPrice = tripPrice * travelerCount;

  trip.remainingCapacity = trip.remainingCapacity - travelerCount;
  await trip.save();

  const reservation = await Reservation.create({
    customerEmail: customerEmail,
    tripCode: cleanCode,
    travelers: travelerCount,
    totalPrice: totalPrice,
    status: 'confirmed'
  });

  return reservation;
};

const getReservationsForCustomer = async function(customerEmail) {
  if (!customerEmail) {
    throw new Error('Missing customer email');
  }

  return await Reservation.find({ customerEmail: customerEmail })
    .sort({ createdOn: -1 });
};

const getReservationReport = async function() {
  return await Reservation.aggregate([
    {
      $match: {
        status: 'confirmed'
      }
    },
    {
      $group: {
        _id: '$tripCode',
        reservationCount: { $sum: 1 },
        totalTravelers: { $sum: '$travelers' },
        estimatedRevenue: { $sum: '$totalPrice' }
      }
    },
    {
      $sort: {
        reservationCount: -1,
        _id: 1
      }
    },
    {
      $project: {
        _id: 0,
        tripCode: '$_id',
        reservationCount: 1,
        totalTravelers: 1,
        estimatedRevenue: 1
      }
    }
  ]);
};

module.exports = {
  createReservation,
  getReservationsForCustomer,
  getReservationReport
};