const reservationService = require('../services/reservationService');

const getCustomerEmail = function(req) {
  if (req.payload && req.payload.email) {
    return req.payload.email;
  }

  if (req.auth && req.auth.email) {
    return req.auth.email;
  }

  return null;
};

const createReservation = async function(req, res) {
  try {
    const customerEmail = getCustomerEmail(req);

    if (!customerEmail) {
      return res.status(401).json({ message: 'User email not found in token' });
    }

    const reservation = await reservationService.createReservation(
      customerEmail,
      req.body.tripCode,
      req.body.travelers
    );

    res.status(201).json(reservation);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const listReservations = async function(req, res) {
  try {
    const customerEmail = getCustomerEmail(req);

    if (!customerEmail) {
      return res.status(401).json({ message: 'User email not found in token' });
    }

    const reservations = await reservationService.getReservationsForCustomer(
      customerEmail
    );

    res.status(200).json(reservations);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

const reservationReport = async function(req, res) {
  try {
    const report = await reservationService.getReservationReport();
    res.status(200).json(report);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

module.exports = {
  createReservation,
  listReservations,
  reservationReport
};