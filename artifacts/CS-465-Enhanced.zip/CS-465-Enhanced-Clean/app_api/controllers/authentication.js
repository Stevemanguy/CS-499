const passport = require('passport');
const User = require('../models/user');

const register = async function(req, res) {
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res.status(400).json({
      message: 'All fields are required.'
    });
  }

  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email
    });

    user.setPassword(req.body.password);
    await user.save();

    return res.status(200).json({
      token: user.generateJWT()
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        message: 'That email address is already registered.'
      });
    }

    return res.status(500).json({
      message: error.message
    });
  }
};

const login = function(req, res) {
  if (!req.body.email || !req.body.password) {
    return res.status(400).json({
      message: 'All fields are required.'
    });
  }

  passport.authenticate('local', function(error, user, info) {
    if (error) {
      return res.status(500).json({
        message: error.message
      });
    }

    if (!user) {
      return res.status(401).json(info);
    }

    return res.status(200).json({
      token: user.generateJWT()
    });
  })(req, res);
};

module.exports = {
  register,
  login
};