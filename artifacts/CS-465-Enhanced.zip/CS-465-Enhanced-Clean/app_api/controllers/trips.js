const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({});

    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: 'No trips found' });
    }

    res.status(200).json(trips);
  } catch (err) {
    res.status(500).json({
      message: 'Error retrieving trips',
      error: err.message
    });
  }
};

const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip.findOne({
      code: req.params.tripCode
    });

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${req.params.tripCode} not found`
      });
    }

    res.status(200).json(trip);
  } catch (err) {
    res.status(500).json({
      message: 'Error retrieving trip',
      error: err.message
    });
  }
};

const tripsAddOne = async (req, res) => {
  try {
    const existingTrip = await Trip.findOne({
      code: req.body.code
    });

    if (existingTrip) {
      return res.status(409).json({
        message: `Trip with code ${req.body.code} already exists`
      });
    }

    const newTrip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description,
      description2: req.body.description2
    });

    res.status(201).json(newTrip);
  } catch (err) {
    res.status(400).json({
      message: 'Error creating trip',
      error: err.message
    });
  }
};

const tripsUpdateOne = async (req, res) => {
  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description,
        description2: req.body.description2
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!updatedTrip) {
      return res.status(404).json({
        message: `Trip with code ${req.params.tripCode} not found`
      });
    }

    res.status(200).json(updatedTrip);
  } catch (err) {
    res.status(400).json({
      message: 'Error updating trip',
      error: err.message
    });
  }
};

const tripsDeleteOne = async (req, res) => {
  try {
    const deletedTrip = await Trip.findOneAndDelete({
      code: req.params.tripCode
    });

    if (!deletedTrip) {
      return res.status(404).json({
        message: `Trip with code ${req.params.tripCode} not found`
      });
    }

    res.status(200).json({
      message: `Trip ${req.params.tripCode} deleted successfully`
    });
  } catch (err) {
    res.status(500).json({
      message: 'Error deleting trip',
      error: err.message
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddOne,
  tripsUpdateOne,
  tripsDeleteOne
};