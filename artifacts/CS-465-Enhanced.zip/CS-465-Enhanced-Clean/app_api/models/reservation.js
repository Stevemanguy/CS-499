const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema({
  customerEmail: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    match: /.+\@.+\..+/
  },
  tripCode: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  travelers: {
    type: Number,
    required: true,
    min: 1,
    max: 10
  },
  totalPrice: {
    type: Number,
    required: true,
    min: 0
  },
  status: {
    type: String,
    enum: ['confirmed', 'cancelled'],
    default: 'confirmed'
  },
  createdOn: {
    type: Date,
    default: Date.now
  }
});

reservationSchema.index({ customerEmail: 1, createdOn: -1 });
reservationSchema.index({ tripCode: 1 });
reservationSchema.index({ status: 1 });

mongoose.model('reservations', reservationSchema);