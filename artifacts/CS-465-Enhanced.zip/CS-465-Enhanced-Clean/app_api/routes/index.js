const express = require('express');
const router = express.Router();
const { expressjwt: jwt } = require('express-jwt');

const ctrlReservations = require('../controllers/reservations');

const tripsController = require('../controllers/trips');
const authenticationController = require('../controllers/authentication');

const auth = jwt({
  secret: process.env.JWT_SECRET,
  algorithms: ['HS256']
});

router.post('/register', authenticationController.register);
router.post('/login', authenticationController.login);

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(auth, tripsController.tripsAddOne);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(auth, tripsController.tripsUpdateOne)
  .delete(auth, tripsController.tripsDeleteOne);

router
  .route('/reservations/report')
  .get(auth, ctrlReservations.reservationReport);

router
  .route('/reservations')
  .post(auth, ctrlReservations.createReservation)
  .get(auth, ctrlReservations.listReservations);

module.exports = router;