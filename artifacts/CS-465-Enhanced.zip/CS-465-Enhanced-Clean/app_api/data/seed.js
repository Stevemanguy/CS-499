const mongoose = require('mongoose');
require('../models/db');

const Trip = mongoose.model('trips');
const trips = require('./trips.json');

const seedDatabase = async () => {
  try {
    await Trip.deleteMany({});
    await Trip.insertMany(trips);
    console.log('Trips database seeded successfully.');
  } catch (err) {
    console.error('Error seeding trips database:', err);
  } finally {
    mongoose.connection.close();
  }
};

mongoose.connection.once('open', seedDatabase);