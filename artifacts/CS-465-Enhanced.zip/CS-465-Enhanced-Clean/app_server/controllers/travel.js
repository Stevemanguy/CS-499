const apiOptions = {
  server: 'http://localhost:3000'
};

const renderTravelPage = (req, res, responseBody) => {
  res.render('travel', {
    title: 'Travlr Getaways',
    trips: responseBody
  });
};

const travel = async (req, res) => {
  try {
    const response = await fetch(`${apiOptions.server}/api/trips`);
    const trips = await response.json();

    if (!response.ok) {
      return res.status(response.status).render('error', {
        message: 'Unable to retrieve trip data from API',
        error: trips
      });
    }

    renderTravelPage(req, res, trips);
  } catch (err) {
    res.status(500).render('error', {
      message: 'Unable to retrieve trip data from API',
      error: err
    });
  }
};

module.exports = {
  travel
};