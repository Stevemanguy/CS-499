import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
 standalone: true,
  selector: 'app-add-trip',
  imports: [ReactiveFormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip {
  private formBuilder = inject(FormBuilder);
  private router = inject(Router);
  private tripData = inject(TripData);

  tripForm = this.formBuilder.nonNullable.group({
    code: ['', Validators.required],
    name: ['', Validators.required],
    length: ['', Validators.required],
    start: ['', Validators.required],
    resort: ['', Validators.required],
    perPerson: ['', Validators.required],
    image: ['reef1.jpg', Validators.required],
    description: ['', Validators.required],
    description2: ['']
  });

  saveTrip(): void {
    if (this.tripForm.invalid) {
      this.tripForm.markAllAsTouched();
      return;
    }

    const trip: Trip = this.tripForm.getRawValue();

    this.tripData.addTrip(trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Unable to add trip:', error);
      }
    });
  }

  cancel(): void {
    this.router.navigate(['/']);
  }
}