import { Component, inject, OnInit } from '@angular/core';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
 standalone: true,
  selector: 'app-edit-trip',
  imports: [ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  private formBuilder = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private tripData = inject(TripData);

  tripForm = this.formBuilder.nonNullable.group({
    code: ['', Validators.required],
    name: ['', Validators.required],
    length: ['', Validators.required],
    start: ['', Validators.required],
    resort: ['', Validators.required],
    perPerson: ['', Validators.required],
    image: ['', Validators.required],
    description: ['', Validators.required],
    description2: ['']
  });

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');

    if (!tripCode) {
      this.router.navigate(['/']);
      return;
    }

    this.tripData.getTrip(tripCode).subscribe({
      next: (trip: Trip) => {
        this.tripForm.patchValue({
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: trip.start.substring(0, 10),
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description,
          description2: trip.description2
        });
      },
      error: (error) => {
        console.error('Unable to retrieve trip:', error);
        this.router.navigate(['/']);
      }
    });
  }

  saveTrip(): void {
    if (this.tripForm.invalid) {
      this.tripForm.markAllAsTouched();
      return;
    }

    const trip: Trip = this.tripForm.getRawValue();

    this.tripData.updateTrip(trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Unable to update trip:', error);
      }
    });
  }
  
  deleteTrip(): void {
    const tripCode = this.tripForm.controls.code.value;

    if (!tripCode) {
      return;
    }

    const confirmed = window.confirm(
      `Are you sure you want to delete ${tripCode}?`
    );

    if (!confirmed) {
      return;
    }

    this.tripData.deleteTrip(tripCode).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error) => {
        console.error('Unable to delete trip:', error);
      }
    });
  }


  cancel(): void {
    this.router.navigate(['/']);
  }
}