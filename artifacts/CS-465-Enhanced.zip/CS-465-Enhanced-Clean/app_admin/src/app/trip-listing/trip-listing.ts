import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TripCard } from '../trip-card/trip-card';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { AuthenticationService } from '../services/authentication';
import { RouterLink } from '@angular/router';

@Component({
 standalone: true,
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCard, RouterLink],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {
  trips = signal<Trip[]>([]);

  private tripData = inject(TripData);
  private authService = inject(AuthenticationService);


  ngOnInit(): void {
    this.tripData.getTrips().subscribe({
      next: (trips: Trip[]) => {
        this.trips.set(trips);
      },
      error: (error) => {
        console.error('Unable to retrieve trips:', error);
      }
    });
  }
  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }
}