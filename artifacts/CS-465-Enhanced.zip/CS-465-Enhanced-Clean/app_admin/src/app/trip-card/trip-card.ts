import { Component, inject, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import { Trip } from '../models/trip';
import { AuthenticationService } from '../services/authentication';

@Component({
standalone: true,
selector: 'app-trip-card',
imports: [CommonModule, RouterLink],
templateUrl: './trip-card.html',
styleUrl: './trip-card.css'
})
export class TripCard {
@Input() trip!: Trip;

private authService = inject(AuthenticationService);

isLoggedIn(): boolean {
return this.authService.isLoggedIn();
}
}
