export class Trip {
  _id?: string;
  code!: string;
  name!: string;
  length!: string;
  start!: string;
  resort!: string;
  perPerson!: string;
  image!: string;
  description!: string;
  description2!: string;
}